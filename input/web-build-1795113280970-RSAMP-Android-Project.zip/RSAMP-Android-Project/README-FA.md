# پروژه RSAMP Control برای اندروید

این پوشه یک پروژه Android Studio است که رابط فعلی RSAMP Control را داخل WebView اجرا می‌کند.

## ساخت APK
1. Android Studio را نصب کنید.
2. پوشه `RSAMP-Android-Project` را از طریق **Open** باز کنید.
3. صبر کنید Gradle Sync کامل شود (این پروژه به Android SDK 35 و JDK 17 نیاز دارد).
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** خروجی بگیرید.
5. APK دیباگ معمولاً در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

## وضعیت فعلی و محدودیت‌ها
- رابط وب در `app/src/main/assets/index.html` قرار دارد.
- تم روشن/تاریک، کلیدهای نمایشی و فرم ورود نام اکانت در خود رابط کار می‌کنند.
- وضعیت سرور، پینگ، لول، پول، ساعت بازی و شناسایی واقعی اکانت هنوز به API سرور وصل نیستند؛ اطلاعات واقعی جعل یا حدس زده نمی‌شوند.
- فایل `original-apk/AndroidForge-app-debug.apk` همان APK ارسالی شماست و نسخه اصلاح‌شده یا بازسازی‌شده نیست.
- این محیط ابزار Android SDK/Gradle برای تولید و امضای APK ندارد؛ بنابراین APK جدید در این بسته ساخته نشده است.

برای اتصال واقعی باید سورس کامل برنامه اصلی (پروژه Android Studio، نه فقط APK) و مستندات/API سرور فراهم شود.
