RSAMP Android project. See README-FA.md for build instructions and current limitations.
