AG Runner - Android (Kotlin + Jetpack Compose)  |  by GodMoor

BUILD
 1) Open this folder in Android Studio (Koala or newer) and let Gradle sync.
 2) Build > Build APK(s)   (or Run on a phone).

THE CLIENT
 AGRakClient.exe is a Windows program and cannot run on Android.
 This app runs a native Android client named libagrakclient.so placed in
 app/src/main/jniLibs/arm64-v8a/ (and armeabi-v7a if needed).
 It must work like the exe: read username + password from stdin (one per line) and print
 "[user] Login successfully." / "Reconnecting in ..." lines to stdout.
 Without that file the app starts, but accounts will log "libagrakclient.so not found".
