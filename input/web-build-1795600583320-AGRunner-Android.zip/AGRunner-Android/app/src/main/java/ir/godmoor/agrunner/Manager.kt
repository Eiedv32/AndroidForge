package ir.godmoor.agrunner

import android.os.Handler
import android.os.Looper

/**
 * Port of the Windows runner logic: only ONE account connects at a time (the "gate");
 * a second account that starts "Reconnecting" is stopped and re-queued; login timeout keeps the queue moving.
 * Everything runs on the main thread.
 */
class Manager(val settings: Settings, private val engine: Engine) {
    companion object { const val CONNECT_TIMEOUT_SEC = 120 }

    val accounts = androidx.compose.runtime.mutableStateListOf<Account>()
    private var gate: Account? = null
    private val main = Handler(Looper.getMainLooper())

    fun add(a: Account) {
        accounts.add(a)
        a.onLoggedIn = { acc -> if (gate === acc) gate = null; acc.gateSince = null }
        a.onReconnectSeen = { acc ->
            if (gate == null) { gate = acc; acc.gateSince = System.currentTimeMillis() }
            else if (gate !== acc) {
                acc.addLog("Another account is connecting; waiting for my turn.")
                acc.kill(ExitReason.Requeue)
            }
        }
        a.onExited = ::onExited
    }

    fun remove(a: Account) { stop(a); if (gate === a) gate = null; accounts.remove(a) }

    private fun onExited(a: Account, reason: ExitReason, code: Int) {
        if (gate === a) gate = null
        a.gateSince = null
        val now = System.currentTimeMillis()
        when (reason) {
            ExitReason.UserStop ->
                if (a.wanted) { a.nextAttempt = now + 1000; a.setState(RunState.Queued) } else a.setState(RunState.Stopped)
            ExitReason.Requeue -> { a.nextAttempt = now + 2000; a.setState(RunState.Queued) }
            ExitReason.Timeout -> { a.nextAttempt = now + 10_000; a.setState(RunState.Queued) }
            else -> {
                if (settings.autoReconnect && a.wanted) { a.nextAttempt = now + 5000; a.addLog("Restarting in 5 seconds...") }
                else a.wanted = false
                a.setState(RunState.Crashed)
            }
        }
    }

    fun start(a: Account) { queue(a); tick() }
    fun startAll() { accounts.forEach { queue(it) }; tick() }
    private fun queue(a: Account) {
        a.wanted = true
        if (a.handle == null) { a.nextAttempt = 0; a.setState(RunState.Queued) }
    }

    fun stop(a: Account) {
        a.wanted = false
        if (a.handle != null) a.kill(ExitReason.UserStop)
        else { if (gate === a) gate = null; a.setState(RunState.Stopped) }
    }
    fun stopAll() = accounts.toList().forEach { stop(it) }

    fun anyWanted() = accounts.any { it.wanted }

    /** Call once per second. */
    fun tick() {
        val now = System.currentTimeMillis()
        for (a in accounts) {
            if (!a.wanted) continue
            if (a.handle != null) {
                val since = a.gateSince
                if (gate === a && since != null && now - since > CONNECT_TIMEOUT_SEC * 1000L) {
                    a.addLog("No login after ${CONNECT_TIMEOUT_SEC}s; trying again later.")
                    a.kill(ExitReason.Timeout)
                }
                continue
            }
            if (now < a.nextAttempt || gate != null) continue

            if (!engine.isAvailable()) {
                a.addLog("Failed: " + engine.missingMessage())
                a.wanted = false; a.setState(RunState.Crashed); continue
            }
            gate = a; a.gateSince = now
            a.reason = ExitReason.None
            val h = engine.launch(a,
                onLine = { line -> main.post { a.handleLine(line) } },
                onExit = { code -> main.post { handleExit(a, code) } })
            if (h == null) { gate = null; a.gateSince = null; a.wanted = false; a.setState(RunState.Crashed) }
            else { a.handle = h; a.addLog("Launching client..."); a.setState(RunState.Connecting) }
        }
    }

    private fun handleExit(a: Account, code: Int) {
        if (a.handle == null) return
        a.handle = null
        val r = a.reason; a.reason = ExitReason.None
        a.addLog(when (r) {
            ExitReason.UserStop -> "Stopped."
            ExitReason.Requeue -> "Re-queued: another account is connecting."
            ExitReason.Timeout -> "Client stopped (login timeout)."
            else -> "Failed: process exited unexpectedly (code $code)."
        })
        a.onExited?.invoke(a, r, code)
    }
}
