package ir.godmoor.agrunner

import android.content.Context
import java.io.File
import java.io.PrintWriter

interface EngineHandle { fun kill() }

/** A client engine: connects ONE account and reports log lines + exit code (callbacks come from any thread). */
interface Engine {
    fun isAvailable(): Boolean
    fun missingMessage(): String
    fun launch(acc: Account, onLine: (String) -> Unit, onExit: (Int) -> Unit): EngineHandle?
}

/**
 * Runs the native Android build of the client (libagrakclient.so, put it in app/src/main/jniLibs/<abi>/).
 * It must behave like AGRakClient.exe: reads username + password from stdin (one per line) and prints the
 * same log lines ("[user] Login successfully.", "Reconnecting in ...") to stdout.
 */
class ProcessEngine(private val ctx: Context) : Engine {
    private fun lib() = File(ctx.applicationInfo.nativeLibraryDir, "libagrakclient.so")
    override fun isAvailable() = lib().exists()
    override fun missingMessage() = "libagrakclient.so not found (put the Android client in jniLibs)"

    override fun launch(acc: Account, onLine: (String) -> Unit, onExit: (Int) -> Unit): EngineHandle? {
        val p = try {
            ProcessBuilder(lib().absolutePath, "--from-py")
                .directory(ctx.filesDir).redirectErrorStream(true).start()
        } catch (e: Exception) {
            onLine("Failed to start client: ${e.message}")
            return null
        }
        try {
            PrintWriter(p.outputStream.bufferedWriter(), true).apply { println(acc.username); println(acc.password) }
        } catch (e: Exception) { onLine("Could not send credentials: ${e.message}") }
        Thread {
            try { p.inputStream.bufferedReader().forEachLine { if (it.isNotBlank()) onLine(it.trimEnd()) } } catch (_: Exception) {}
            val code = try { p.waitFor() } catch (_: Exception) { -1 }
            onExit(code)
        }.apply { isDaemon = true }.start()
        return object : EngineHandle { override fun kill() { p.destroyForcibly() } }
    }
}
