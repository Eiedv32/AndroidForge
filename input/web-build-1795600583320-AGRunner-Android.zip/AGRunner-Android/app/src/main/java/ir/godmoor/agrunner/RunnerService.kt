package ir.godmoor.agrunner

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Keeps the runner alive in the background (foreground notification + wake lock) and ticks the queue every second. */
class RunnerService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private val loop = object : Runnable {
        override fun run() {
            val m = App.manager ?: return stopSelf()
            m.tick()
            val online = m.accounts.count { it.state == RunState.Online }
            notify("$online/${m.accounts.size} آنلاین")
            if (!m.anyWanted() && m.accounts.none { it.handle != null }) { stopSelf(); return }
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("ag", "AG Runner", NotificationManager.IMPORTANCE_LOW))
        val n = build("در حال اجرا")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        if (wl == null) {
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ag:run").apply { acquire() }
        }
        h.removeCallbacks(loop); h.post(loop)
        return START_STICKY
    }

    private fun build(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ag") else Notification.Builder(this)
        return b.setContentTitle("AG Runner").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(pi).setOngoing(true).build()
    }
    private fun notify(text: String) = getSystemService(NotificationManager::class.java).notify(1, build(text))

    override fun onDestroy() { h.removeCallbacks(loop); wl?.let { if (it.isHeld) it.release() }; wl = null; super.onDestroy() }
}
