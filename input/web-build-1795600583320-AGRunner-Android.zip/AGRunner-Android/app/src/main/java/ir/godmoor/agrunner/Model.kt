package ir.godmoor.agrunner

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class RunState { Stopped, Queued, Connecting, Online, Crashed }
enum class ExitReason { None, UserStop, Requeue, Timeout }

class Settings(var autoReconnect: Boolean = true, var autoStartOnLaunch: Boolean = false)

class Account(val username: String, var password: String) {
    var state by mutableStateOf(RunState.Stopped)
    var onlineSince by mutableStateOf<Long?>(null)
    val log = mutableStateListOf<String>()

    var wanted = false
    var nextAttempt = 0L
    var gateSince: Long? = null
    var handle: EngineHandle? = null
    var reason = ExitReason.None

    var onLoggedIn: ((Account) -> Unit)? = null
    var onReconnectSeen: ((Account) -> Unit)? = null
    var onExited: ((Account, ExitReason, Int) -> Unit)? = null

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun addLog(text: String) {
        log.add("[${fmt.format(Date())}] $text")
        while (log.size > 400) log.removeAt(0)
    }

    fun setState(s: RunState) {
        if (s == state) return
        state = s
        if (s == RunState.Online) { if (onlineSince == null) onlineSince = System.currentTimeMillis() }
        else if (s != RunState.Connecting) onlineSince = null
    }

    /** Same detection as the original Python / Windows runner. Must be called on the main thread. */
    fun handleLine(line: String) {
        addLog(line)
        if (line.contains("[$username] Login successfully.") || line.contains("[$username] Welcome $username!")) {
            if (onlineSince == null) onlineSince = System.currentTimeMillis()
            setState(RunState.Online)
            onLoggedIn?.invoke(this)
        } else if (!line.contains("[CMSG]") && line.contains(" Reconnecting in ")) {
            if (state == RunState.Online) setState(RunState.Connecting)
            onReconnectSeen?.invoke(this)
        }
    }

    fun kill(r: ExitReason) {
        val h = handle ?: return
        reason = r
        h.kill()
    }
}
