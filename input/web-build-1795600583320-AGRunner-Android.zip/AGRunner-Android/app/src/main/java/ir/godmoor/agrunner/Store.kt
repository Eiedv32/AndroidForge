package ir.godmoor.agrunner

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Passwords are encrypted with an Android Keystore key (never leaves the device). */
private object Crypto {
    private const val ALIAS = "ag_runner_key"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }
    fun enc(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        return Base64.encodeToString(c.iv + c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }
    fun dec(s: String): String = try {
        val b = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12)) }
        String(c.doFinal(b, 12, b.size - 12))
    } catch (_: Exception) { "" }
}

class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("ag", Context.MODE_PRIVATE)

    fun load(): Pair<Settings, List<Account>> {
        val s = Settings(); val list = mutableListOf<Account>()
        try {
            val j = JSONObject(prefs.getString("data", "{}")!!)
            s.autoReconnect = j.optBoolean("autoReconnect", true)
            s.autoStartOnLaunch = j.optBoolean("autoStart", false)
            val arr = j.optJSONArray("accounts") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Account(o.getString("u"), Crypto.dec(o.getString("p"))))
            }
        } catch (_: Exception) {}
        return s to list
    }

    fun save(s: Settings, accounts: List<Account>) {
        val arr = JSONArray()
        accounts.forEach { arr.put(JSONObject().put("u", it.username).put("p", Crypto.enc(it.password))) }
        val j = JSONObject().put("autoReconnect", s.autoReconnect).put("autoStart", s.autoStartOnLaunch).put("accounts", arr)
        prefs.edit().putString("data", j.toString()).apply()
    }
}
