package ir.godmoor.agrunner

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.delay

private val Bg = Color(0xFF080809)
private val Red = Color(0xFFFF3333)
private val Ok = Color(0xFF3DDC84)
private val Warn = Color(0xFFFFB84D)
private val Muted = Color(0xFF968C91)
private val TextC = Color(0xFFF1EEEF)
private val Chat = Color(0xFF96ACD6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = App.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (mgr.settings.autoStartOnLaunch && mgr.accounts.isNotEmpty()) { mgr.startAll(); startRunner() }
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Bg, onSurface = TextC)) {
                    Screen(mgr, onStart = { startRunner() })
                }
            }
        }
    }
    private fun startRunner() {
        val i = Intent(this, RunnerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
}

private fun stateText(a: Account, now: Long) = when (a.state) {
    RunState.Online -> "آنلاین · " + fmt(now - (a.onlineSince ?: now))
    RunState.Connecting -> "در حال اتصال..."
    RunState.Queued -> "در انتظار نوبت"
    RunState.Crashed -> if (a.wanted) "کرش · تلاش مجدد" else "ناموفق"
    RunState.Stopped -> "متوقف"
}
private fun stateColor(s: RunState) = when (s) {
    RunState.Online -> Ok; RunState.Connecting, RunState.Queued -> Warn; RunState.Crashed -> Red; else -> Muted
}
private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "${s / 3600}h ${s % 3600 / 60}m" else if (s >= 60) "${s / 60}m ${s % 60}s" else "${s}s"
}
private fun lineColor(l: String) = when {
    l.contains("[CMSG]") -> Chat
    l.contains("Login successfully") || l.contains(" Welcome ") -> Ok
    l.contains("Failed") || l.contains("not found") -> Red
    l.contains("Reconnecting") || l.contains("Restarting") || l.contains("Re-queued") || l.contains("Another account") ||
        l.contains("timeout", true) || l.contains("disconnect", true) -> Warn
    else -> Muted
}

@Composable
private fun Glass(modifier: Modifier = Modifier, selected: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Red.copy(alpha = if (selected) .28f else .16f), Color.White.copy(alpha = .03f))))
            .border(BorderStroke(1.dp, Red.copy(alpha = if (selected) .8f else .35f)), RoundedCornerShape(20.dp))
            .padding(14.dp), content = content
    )
}

@Composable
private fun Screen(mgr: Manager, onStart: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    var selected by remember { mutableStateOf<Account?>(null) }
    var dialog by remember { mutableStateOf<Account?>(null) }   // edit target
    var adding by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<Account?>(null) }
    var menu by remember { mutableStateOf(false) }
    var settingsTick by remember { mutableIntStateOf(0) }
    val sel = selected?.takeIf { it in mgr.accounts } ?: mgr.accounts.firstOrNull()
    val online = mgr.accounts.count { it.state == RunState.Online }
    val busy = mgr.accounts.count { it.state == RunState.Connecting || it.state == RunState.Queued }
    val bad = mgr.accounts.count { it.state == RunState.Crashed }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.fillMaxWidth().height(260.dp).background(Brush.verticalGradient(listOf(Red.copy(alpha = .22f), Color.Transparent))))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AG Runner", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextC)
                    Text("مدیریت چند اکانت · GodMoor", fontSize = 12.sp, color = Muted)
                }
                Box {
                    TextButton(onClick = { menu = true }) { Text("تنظیمات", color = Red) }
                    DropdownMenu(menu, { menu = false }) {
                        key(settingsTick) {
                            DropdownMenuItem(
                                text = { Text((if (mgr.settings.autoReconnect) "✓ " else "") + "اتصال مجدد خودکار") },
                                onClick = { mgr.settings.autoReconnect = !mgr.settings.autoReconnect; App.save(); settingsTick++ })
                            DropdownMenuItem(
                                text = { Text((if (mgr.settings.autoStartOnLaunch) "✓ " else "") + "شروع اکانت‌ها هنگام باز شدن") },
                                onClick = { mgr.settings.autoStartOnLaunch = !mgr.settings.autoStartOnLaunch; App.save(); settingsTick++ })
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("آنلاین", "$online/${mgr.accounts.size}", Ok, Modifier.weight(1f))
                Chip("در حال اتصال", "$busy", Warn, Modifier.weight(1f))
                Chip("مشکل‌دار", "$bad", Red, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ mgr.startAll(); onStart() }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
                    shape = RoundedCornerShape(14.dp)) { Text("شروع همه") }
                OutlinedButton({ mgr.stopAll() }, Modifier.weight(1f), shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Red.copy(alpha = .6f))) { Text("توقف همه", color = TextC) }
            }

            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mgr.accounts.isEmpty()) item { Text("برای شروع یک اکانت اضافه کنید", color = Muted, modifier = Modifier.padding(24.dp)) }
                items(mgr.accounts, key = { it.username }) { a ->
                    Glass(Modifier.fillMaxWidth().clickable { selected = a }, selected = a === sel) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(stateColor(a.state)))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.username, fontWeight = FontWeight.SemiBold, color = TextC)
                                Text(stateText(a, now), fontSize = 12.sp, color = stateColor(a.state))
                            }
                            IconButton({ if (a.wanted) mgr.stop(a) else { mgr.start(a); onStart() } }) {
                                Text(if (a.wanted) "توقف" else "شروع", color = if (a.wanted) Warn else Ok, fontWeight = FontWeight.Bold)
                            }
                            IconButton({ if (a.wanted) { a.addLog("Stop the account before editing it.") } else dialog = a }) { Icon(Icons.Default.Edit, "ویرایش", tint = Muted) }
                            IconButton({ removing = a }) { Icon(Icons.Default.Delete, "حذف", tint = Red) }
                        }
                    }
                }
            }

            Glass(Modifier.fillMaxWidth().height(190.dp)) {
                Row { Text(sel?.username ?: "لاگ", color = TextC, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    sel?.let { s -> Text("پاک کردن", color = Red, fontSize = 12.sp, modifier = Modifier.clickable { s.log.clear() }) } }
                val ls = rememberLazyListState()
                val logs = sel?.log
                LaunchedEffect(logs?.size) { logs?.let { if (it.isNotEmpty()) ls.scrollToItem(it.size - 1) } }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    LazyColumn(state = ls) { items(logs ?: emptyList()) { Text(it, color = lineColor(it), fontSize = 11.sp, fontFamily = FontFamily.Monospace) } }
                }
            }
        }
        FloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(24.dp).padding(bottom = 210.dp),
            containerColor = Red, contentColor = Color.White) { Icon(Icons.Default.Add, "افزودن") }
    }

    if (adding || dialog != null) {
        val edit = dialog
        AccountDialog(if (edit == null) "افزودن اکانت" else "ویرایش اکانت", edit?.username ?: "", edit?.password ?: "",
            onDismiss = { adding = false; dialog = null }) { u, p ->
            if (edit == null) {
                if (mgr.accounts.any { it.username.equals(u, true) }) return@AccountDialog "این نام کاربری قبلاً در لیست هست."
                mgr.add(Account(u, p))
            } else {
                val idx = mgr.accounts.indexOf(edit)
                if (mgr.accounts.any { it !== edit && it.username.equals(u, true) }) return@AccountDialog "این نام کاربری قبلاً در لیست هست."
                if (idx >= 0) mgr.accounts[idx] = Account(u, p).also { n -> n.onLoggedIn = edit.onLoggedIn; n.onReconnectSeen = edit.onReconnectSeen; n.onExited = edit.onExited }
            }
            App.save(); adding = false; dialog = null; null
        }
    }
    removing?.let { a ->
        AlertDialog(onDismissRequest = { removing = null },
            title = { Text("«${a.username}» حذف شود؟") },
            confirmButton = { TextButton({ mgr.remove(a); App.save(); removing = null }) { Text("حذف", color = Red) } },
            dismissButton = { TextButton({ removing = null }) { Text("انصراف") } })
    }
}

@Composable
private fun Chip(label: String, value: String, color: Color, modifier: Modifier) {
    Glass(modifier) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable
private fun AccountDialog(title: String, u0: String, p0: String, onDismiss: () -> Unit, onSave: (String, String) -> String?) {
    var u by remember { mutableStateOf(u0) }
    var p by remember { mutableStateOf(p0) }
    var show by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(u, { u = it }, label = { Text("نام کاربری") }, singleLine = true)
                OutlinedTextField(p, { p = it }, label = { Text("رمز عبور") }, singleLine = true,
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation())
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(show, { show = it }); Text("نمایش رمز", fontSize = 13.sp) }
                err?.let { Text(it, color = Red, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton({
                val a = u.trim(); val b = p.trim()
                err = when {
                    a.isEmpty() || b.isEmpty() -> "نام کاربری و رمز عبور الزامی است."
                    a.any { it.isWhitespace() } || b.any { it.isWhitespace() } -> "فاصله مجاز نیست: کلاینت نام کاربری و رمز را تک‌کلمه می‌خواند."
                    else -> onSave(a, b)
                }
            }) { Text("ذخیره", color = Red) }
        },
        dismissButton = { TextButton(onDismiss) { Text("انصراف") } })
}
