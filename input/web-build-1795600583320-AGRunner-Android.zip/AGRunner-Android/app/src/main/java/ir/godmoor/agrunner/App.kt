package ir.godmoor.agrunner

import android.content.Context

/** Process-wide holder so the UI and the foreground service share one Manager. */
object App {
    var manager: Manager? = null
    lateinit var store: Store

    fun init(ctx: Context): Manager {
        manager?.let { return it }
        val app = ctx.applicationContext
        store = Store(app)
        val (settings, accounts) = store.load()
        return Manager(settings, ProcessEngine(app)).also { m ->
            accounts.forEach { m.add(it) }
            manager = m
        }
    }

    fun save() { manager?.let { store.save(it.settings, it.accounts) } }
}
