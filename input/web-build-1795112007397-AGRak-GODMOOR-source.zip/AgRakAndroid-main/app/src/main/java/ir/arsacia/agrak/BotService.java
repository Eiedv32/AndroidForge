package ir.arsacia.agrak;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BotService extends Service {
    private static final String TAG = "AGRak_BotService";
    public static final String CHANNEL_ID = "AGRak_Channel";
    public static final int NOTIFICATION_ID = 1001;

    public interface LogCallback {
        void onNewLog(String accountId, String line);
        default void onNewChat(String accountId, String line) {}
        void onStatsUpdated(String accountId, String level, String respect, String rob, String escape);
        default void onConnected(String accountId) {}
        default void onDisconnected(String accountId) {}
        default void onAccountCleared(String accountId) {}
    }

    private static final List<LogCallback> logCallbacks = new CopyOnWriteArrayList<>();
    private static final Map<String, StringBuilder> accountLogs = Collections.synchronizedMap(new HashMap<>());
    private static final Map<String, StringBuilder> accountChat = Collections.synchronizedMap(new HashMap<>());
    private static final Map<String, String[]> cachedStats = Collections.synchronizedMap(new HashMap<>());

    // Running local processes mapped by lowercase nickname
    private static final Map<String, Process> activeProcesses = new ConcurrentHashMap<>();
    private static final Map<String, Thread> readerThreads = new ConcurrentHashMap<>();
    private static final Map<String, String> nickToAccountId = new ConcurrentHashMap<>();
    private static final Map<String, Boolean> connectedAccounts = new ConcurrentHashMap<>();

    private static volatile BotService instance = null;
    private PowerManager.WakeLock wakeLock;

    private static final Pattern PATTERN_LEVEL_RESPECT = Pattern.compile("Level\\s*\\[(\\d+)\\]\\s*Respect\\s*\\[([0-9/]+)\\]", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_ROB_ESCAPE = Pattern.compile("Rob points\\s*\\[(\\d+)\\]\\s*Escape points\\s*\\[(\\d+)\\]", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_LEVEL = Pattern.compile("Level\\s*[:\\[\\s]*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_RESPECT = Pattern.compile("Respect\\s*[:\\[\\s]*([0-9/]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_ROB = Pattern.compile("Rob\\s*(?:points)?\\s*[:\\[\\s]*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PATTERN_ESCAPE = Pattern.compile("Escape\\s*(?:points)?\\s*[:\\[\\s]*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    public static void addLogCallback(LogCallback callback) {
        if (callback != null && !logCallbacks.contains(callback)) {
            logCallbacks.add(callback);
        }
    }

    public static void removeLogCallback(LogCallback callback) {
        if (callback != null) {
            logCallbacks.remove(callback);
        }
    }

    public static String getLogsForAccount(String accountId) {
        if (accountId == null) return "";
        StringBuilder sb = accountLogs.get(accountId);
        return sb != null ? sb.toString() : "";
    }

    public static String getChatForAccount(String accountId) {
        if (accountId == null) return "";
        StringBuilder sb = accountChat.get(accountId);
        return sb != null ? sb.toString() : "";
    }

    public static void clearAccountLogsAndChat(String accountIdOrNick) {
        if (accountIdOrNick == null) return;
        accountLogs.remove(accountIdOrNick);
        accountChat.remove(accountIdOrNick);

        String lower = accountIdOrNick.toLowerCase();
        accountLogs.remove(lower);
        accountChat.remove(lower);

        String mappedId = nickToAccountId.get(lower);
        if (mappedId != null) {
            accountLogs.remove(mappedId);
            accountChat.remove(mappedId);
        }
        for (Map.Entry<String, String> entry : nickToAccountId.entrySet()) {
            if (accountIdOrNick.equalsIgnoreCase(entry.getValue())) {
                accountLogs.remove(entry.getKey());
                accountChat.remove(entry.getKey());
            }
        }

        for (LogCallback cb : logCallbacks) {
            try {
                cb.onAccountCleared(accountIdOrNick);
                if (mappedId != null) {
                    cb.onAccountCleared(mappedId);
                }
            } catch (Exception ignored) {}
        }
    }

    public static void appendChat(String accountId, String line) {
        if (accountId == null || line == null) return;
        if (isStatsDumpLine(line)) return;
        StringBuilder sb = accountChat.computeIfAbsent(accountId, k -> new StringBuilder());
        sb.append(line).append("\n");
        if (sb.length() > 200000) {
            sb.delete(0, 50000);
        }
    }

    public static String stripColorCodes(String str) {
        if (str == null) return "";
        return str.replaceAll("\\{[0-9a-fA-F]{6}\\}", "");
    }

    public static String stripTimestamp(String str) {
        if (str == null) return "";
        int timeEnd = str.indexOf("] ");
        if (str.startsWith("[") && timeEnd > 0 && timeEnd <= 15) {
            return str.substring(timeEnd + 2);
        }
        return str;
    }

    public static boolean isStatsDumpLine(String line) {
        if (line == null) return false;
        String clean = stripColorCodes(stripTimestamp(line.trim())).trim();
        String lower = clean.toLowerCase();

        // 1. Outgoing /stats command
        if (clean.contains("📤 من:") && lower.contains("/stats")) {
            return true;
        }

        // 2. Separators
        if (clean.contains("____________________") || clean.contains("--------------------")) {
            return true;
        }

        // 3. Header: *** [Wz]HarD (183) ***
        if (clean.contains("***") && (clean.contains("(") || clean.contains("["))) {
            return true;
        }

        // 4. Section headers & properties from /stats
        if (clean.contains("Account:") && (clean.contains("Sex") || clean.contains("Cash") || clean.contains("Job") || clean.contains("Phone") || clean.contains("Premium") || clean.contains("Spouse"))) {
            return true;
        }
        if (clean.contains("Activity:") && (clean.contains("Level") || clean.contains("Respect") || clean.contains("AFK") || clean.contains("played") || clean.contains("Online") || clean.contains("Active") || clean.contains("cost"))) {
            return true;
        }
        if (clean.contains("Crimes:") && (clean.contains("Status") || clean.contains("Wanted") || clean.contains("Criminal") || clean.contains("Arrests") || clean.contains("deaths"))) {
            return true;
        }
        if (clean.contains("Punishes:") && (clean.contains("Mute") || clean.contains("jail") || clean.contains("Warn") || clean.contains("punish"))) {
            return true;
        }
        if (clean.contains("Resources:") && (clean.contains("Gold") || clean.contains("Rob") || clean.contains("Escape") || clean.contains("Muscles") || clean.contains("Stomach"))) {
            return true;
        }
        if (clean.contains("Inventory:") && (clean.contains("Drugs") || clean.contains("Materials") || clean.contains("Bombs") || clean.contains("Fish") || clean.contains("Lighter") || clean.contains("Cigarettes") || clean.contains("Lotto") || clean.contains("BS"))) {
            return true;
        }
        if (clean.contains("Faction:") && (clean.contains("Faction") || clean.contains("Rank") || clean.contains("Meeting"))) {
            return true;
        }

        // 5. Individual metric signatures (in case prefix is omitted or wrapped)
        if (clean.contains("Level [") && clean.contains("Respect [")) return true;
        if (clean.contains("Rob points [") || clean.contains("Escape points [")) return true;
        if (clean.contains("AFK time [") || clean.contains("Next level cost [")) return true;
        if (clean.contains("Wanted level [") || clean.contains("Criminal record [")) return true;
        if (clean.contains("Admin jail [") || clean.contains("Faction warns [") || clean.contains("Faction punishes [")) return true;
        if (clean.contains("Total played [") || clean.contains("Hours played [")) return true;
        if (clean.contains("Online time [") || clean.contains("Active time [")) return true;
        if (clean.contains("BS Mats [") || clean.contains("BSMats [")) return true;
        if (clean.contains("Fish [") && clean.contains("Lighter [")) return true;
        if (clean.contains("Premium account [") || clean.contains("Stomach [Empty]")) return true;

        return false;
    }

    public static boolean isServerChatLine(String line) {
        if (line == null) return false;
        String trimmed = line.trim();
        if (trimmed.isEmpty()) return false;

        // Completely filter all stats dump lines and outgoing /stats commands from chat
        if (isStatsDumpLine(trimmed)) {
            return false;
        }

        // User outgoing command or message
        if (trimmed.contains("📤 من:")) {
            return true;
        }

        // Only official SA:MP server client messages or player chat
        if (trimmed.contains("[CHAT]") || trimmed.contains("[CMSG]")) {
            return true;
        }

        return false;
    }

    public static boolean isSmsAd(String line) {
        if (line == null) return false;
        String lower = line.toLowerCase();
        return lower.contains("/sms") ||
                lower.contains("tablighate") ||
                lower.contains("tablighat") ||
                lower.contains("paziraye tablighat") ||
                lower.contains("besparesh dast ma") ||
                lower.contains("nr [") ||
                lower.contains("nr:") ||
                lower.contains("[sms]");
    }

    public static String formatIfServerChat(String line) {
        if (!isServerChatLine(line)) return null;

        String formatted = line.trim();

        // Extract timestamp [HH:MM:SS.mmm] or [HH:MM:SS]
        String timePrefix = "";
        int timeEnd = formatted.indexOf("] ");
        if (formatted.startsWith("[") && timeEnd > 0 && timeEnd <= 15) {
            String rawTime = formatted.substring(1, timeEnd);
            int dotIdx = rawTime.indexOf('.');
            if (dotIdx > 0) {
                rawTime = rawTime.substring(0, dotIdx);
            }
            timePrefix = "[" + rawTime + "] ";
            formatted = formatted.substring(timeEnd + 2).trim();
        }

        if (formatted.startsWith("[CHAT]")) {
            String chatContent = formatted.substring(6).trim();
            return timePrefix + chatContent;
        } else if (formatted.startsWith("[CMSG]")) {
            String cmsgContent = formatted.substring(6).trim();
            return timePrefix + cmsgContent;
        } else {
            return timePrefix + formatted;
        }
    }

    public static void appendLog(String accountId, String line) {
        if (accountId == null || line == null) return;
        StringBuilder sb = accountLogs.computeIfAbsent(accountId, k -> new StringBuilder());
        sb.append(line).append("\n");
        if (sb.length() > 200000) {
            sb.delete(0, 50000);
        }

        parseLineForStats(accountId, line);

        String cleanChat = formatIfServerChat(line);
        if (cleanChat != null && !isStatsDumpLine(cleanChat)) {
            appendChat(accountId, cleanChat);
        }

        for (LogCallback cb : logCallbacks) {
            try {
                cb.onNewLog(accountId, line);
                if (cleanChat != null && !isStatsDumpLine(cleanChat)) {
                    cb.onNewChat(accountId, cleanChat);
                }
            } catch (Exception ignored) {}
        }
    }

    public static void parseLineForStats(String accountId, String line) {
        if (accountId == null || line == null) return;
        String clean = stripColorCodes(line);
        String[] stats = cachedStats.computeIfAbsent(accountId, k -> new String[]{"--", "--", "--", "--"});
        boolean changed = false;

        Matcher mLR = PATTERN_LEVEL_RESPECT.matcher(clean);
        if (mLR.find()) {
            stats[0] = mLR.group(1);
            stats[1] = mLR.group(2);
            changed = true;
        } else {
            Matcher mRes = PATTERN_RESPECT.matcher(clean);
            Matcher mLvl = PATTERN_LEVEL.matcher(clean);
            if (mRes.find()) {
                stats[1] = mRes.group(1);
                changed = true;
                if (mLvl.find()) {
                    stats[0] = mLvl.group(1);
                }
            } else if (clean.contains("Activity:") && mLvl.find()) {
                stats[0] = mLvl.group(1);
                changed = true;
            }
        }

        Matcher mRE = PATTERN_ROB_ESCAPE.matcher(clean);
        if (mRE.find()) {
            stats[2] = mRE.group(1);
            stats[3] = mRE.group(2);
            changed = true;
        } else if (clean.contains("Resources:") || clean.toLowerCase().contains("rob points") || clean.toLowerCase().contains("escape points")) {
            Matcher mRob = PATTERN_ROB.matcher(clean);
            Matcher mEsc = PATTERN_ESCAPE.matcher(clean);
            if (mRob.find()) {
                stats[2] = mRob.group(1);
                changed = true;
            }
            if (mEsc.find()) {
                stats[3] = mEsc.group(1);
                changed = true;
            }
        }

        if (changed) {
            for (Map.Entry<String, String> entry : nickToAccountId.entrySet()) {
                if (accountId.equals(entry.getValue())) {
                    cachedStats.put(entry.getKey(), stats);
                    break;
                }
            }

            for (LogCallback cb : logCallbacks) {
                try {
                    cb.onStatsUpdated(accountId, stats[0], stats[1], stats[2], stats[3]);
                } catch (Exception ignored) {}
            }
        }
    }

    public static String[] getCachedStats(String keyOrId) {
        if (keyOrId == null) return null;
        String[] s = cachedStats.get(keyOrId);
        if (s == null) {
            String accId = nickToAccountId.get(keyOrId.toLowerCase());
            if (accId != null) {
                s = cachedStats.get(accId);
            }
        }
        return s;
    }

    public static void scheduleCommand(String nickname, String cmd, int delaySeconds) {
        if (nickname == null || cmd == null) return;
        try {
            scheduler.schedule(() -> sendLocalCommand(nickname, cmd, false), delaySeconds, TimeUnit.SECONDS);
        } catch (Exception ignored) {}
    }

    public static boolean isBotRunning(String nickname) {
        if (nickname == null) return false;
        String key = nickname.trim().toLowerCase();
        Process proc = activeProcesses.get(key);
        if (proc != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (proc.isAlive()) {
                    return true;
                } else {
                    activeProcesses.remove(key);
                    connectedAccounts.remove(key);
                    return false;
                }
            }
            try {
                proc.exitValue();
                activeProcesses.remove(key);
                connectedAccounts.remove(key);
                return false;
            } catch (IllegalThreadStateException e) {
                return true;
            }
        }
        return false;
    }

    public static boolean isAccountConnected(String nickname) {
        if (nickname == null) return false;
        String key = nickname.trim().toLowerCase();
        if (!isBotRunning(key)) {
            connectedAccounts.remove(key);
            return false;
        }
        return Boolean.TRUE.equals(connectedAccounts.get(key));
    }

    public static int getActiveBotsCount() {
        int count = 0;
        for (Map.Entry<String, Process> entry : activeProcesses.entrySet()) {
            if (isBotRunning(entry.getKey())) {
                count++;
            }
        }
        return count;
    }

    public static synchronized void startLocalBot(Context context, AccountModel acc) {
        if (acc == null || acc.getNickname() == null) return;
        String nick = acc.getNickname().trim();
        String key = nick.toLowerCase();
        nickToAccountId.put(key, acc.getId());
        connectedAccounts.put(key, false);

        // Stop existing process if any
        stopLocalBot(nick);

        nickToAccountId.put(key, acc.getId());
        connectedAccounts.put(key, false);

        // Clear any old logs/chat from previous runs
        clearAccountLogsAndChat(acc.getId());
        clearAccountLogsAndChat(nick);

        if (acc.getPassword() == null || acc.getPassword().trim().isEmpty()) {
            appendLog(acc.getId(), "⚠️ [AGRak] توجه: رمز عبور برای این اکانت ثبت نشده است! لطفاً اکانت را ویرایش نمایید.");
        }

        appendLog(acc.getId(), "[AGRak] آماده‌سازی محیط اجرای داخلی ربات برای " + nick + "...");

        try {
            File botDir = new File(context.getFilesDir(), "bots/" + key);
            botDir.mkdirs();
            File oldLog = new File(botDir, "RakSAMPClient.log");
            if (oldLog.exists()) {
                try { oldLog.delete(); } catch (Exception ignored) {}
            }
            File scriptsDir = new File(botDir, "scripts");
            scriptsDir.mkdirs();
            File luaDir = new File(botDir, "lua");
            luaDir.mkdirs();

            // 1. Copy addon.lua to both lua/ and scripts/
            copyAssetToFile(context, "lua/addon.lua", new File(luaDir, "addon.lua"));
            copyAssetToFile(context, "lua/addon.lua", new File(scriptsDir, "addon.lua"));

            // 2. Prepare autologin.lua and write account_config.lua
            writeAccountConfig(scriptsDir, acc);
            writeAccountConfig(botDir, acc);
            prepareAutologinScript(context, acc, new File(scriptsDir, "autologin.lua"));

            // 3. Write RakSAMPClient.xml (server join password must be empty for ArSaCiA)
            File xmlFile = new File(botDir, "RakSAMPClient.xml");
            writeRakSAMPConfig(xmlFile, nick);

            // 4. Resolve binary path from nativeLibraryDir
            String nativeDir = context.getApplicationInfo().nativeLibraryDir;
            File binary = new File(nativeDir, "libraksamp.so");
            if (!binary.exists()) {
                appendLog(acc.getId(), "[AGRak] ❌ فایل بومی libraksamp.so در مسیر " + nativeDir + " یافت نشد. لطفاً برنامه را مجدداً نصب فرمایید.");
                return;
            }

            appendLog(acc.getId(), "[AGRak] موتور بومی راک‌سمپ: " + binary.getAbsolutePath());
            appendLog(acc.getId(), "[AGRak] در حال اجرای موتور راک‌سمپ با اینترنت گوشی...");

            ProcessBuilder pb = new ProcessBuilder(
                    binary.getAbsolutePath(),
                    "--workdir", botDir.getAbsolutePath(),
                    "--config", xmlFile.getAbsolutePath()
            );
            pb.directory(botDir);
            pb.redirectErrorStream(true);

            Map<String, String> env = pb.environment();
            env.put("LD_LIBRARY_PATH", nativeDir + ":" + botDir.getAbsolutePath());

            Process process = pb.start();
            activeProcesses.put(key, process);

            ensureServiceStarted(context);
            updateNotification();

            // Read output stream
            Thread readerThread = new Thread(() -> {
                final Context appContext = context != null ? context.getApplicationContext() : null;
                final AtomicBoolean hasShownConnectedToast = new AtomicBoolean(false);
                final AtomicBoolean javaPasswordSubmitted = new AtomicBoolean(false);
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        appendLog(acc.getId(), line);

                        String lower = line.toLowerCase();

                        // Check if account has ACTUALLY entered the server world
                        boolean isActuallyInServer = lower.contains("you have been spawned")
                                || lower.contains("spawned!")
                                || lower.contains("confirmed in sleep mode")
                                || lower.contains("put to sleep")
                                || lower.contains("welcome ")
                                || (lower.contains("level [") && lower.contains("respect ["));

                        // Check if server disconnected, kicked, or encountered an error
                        boolean isMyKick = lower.contains("you have been kicked")
                                || (lower.contains(key) && lower.contains("kicked"))
                                || lower.contains("kick-error");

                        boolean isDisconnectOrError = lower.contains("disconnected")
                                || lower.contains("reconnecting")
                                || lower.contains("the connection was lost")
                                || lower.contains("connection was closed")
                                || lower.contains("server closed the connection")
                                || lower.contains("connection attempt failed")
                                || lower.contains("no answer within")
                                || lower.contains("the server did not respond")
                                || lower.contains("server didn't respond")
                                || lower.contains("already logged in")
                                || lower.contains("you are banned")
                                || lower.contains("the server is full")
                                || lower.contains("session reset")
                                || lower.contains("connection rejected")
                                || isMyKick;

                        if (isActuallyInServer) {
                            javaPasswordSubmitted.set(true);
                            Boolean wasConnected = connectedAccounts.put(key, true);
                            if (wasConnected == null || !wasConnected) {
                                for (LogCallback cb : logCallbacks) {
                                    try {
                                        cb.onConnected(acc.getId());
                                        cb.onConnected(key);
                                    } catch (Exception ignored) {}
                                }
                            }
                            updateNotification();
                            // Show connection toast ONLY ONCE per session, only when actually in server
                            if (!hasShownConnectedToast.getAndSet(true)) {
                                final String nickDisplay = (acc.getNickname() != null && !acc.getNickname().trim().isEmpty())
                                        ? acc.getNickname().trim() : acc.getId();
                                if (appContext != null) {
                                    new Handler(Looper.getMainLooper()).post(() -> {
                                        Toast.makeText(appContext, "✅ اکانت " + nickDisplay + " با موفقیت وارد سرور شد", Toast.LENGTH_SHORT).show();
                                    });
                                }
                            }
                        } else if (isDisconnectOrError) {
                            javaPasswordSubmitted.set(false);
                            connectedAccounts.put(key, false);
                            updateNotification();
                            for (LogCallback cb : logCallbacks) {
                                try {
                                    cb.onDisconnected(acc.getId());
                                    cb.onDisconnected(key);
                                } catch (Exception ignored) {}
                            }
                            // IMPORTANT: DO NOT reset hasShownConnectedToast!
                            // It must never re-trigger if an error occurs or on auto-reconnect loops.
                        }

                        // Auto-response in Java as backup ONLY during initial login (NEVER during in-game dialogs/commands)
                        if (acc.isAutoLogin() && !javaPasswordSubmitted.get() && !isActuallyInServer && !Boolean.TRUE.equals(connectedAccounts.get(key))) {
                            boolean isStrictLoginPrompt = lower.contains("type response for [login]")
                                    || lower.contains("type response for [ورود]")
                                    || lower.contains("type response for [رمز]")
                                    || (lower.contains("type response for") && (lower.contains("login") || lower.contains("ورود") || lower.contains("رمز عبور") || lower.contains("password")));

                            if (isStrictLoginPrompt && acc.getPassword() != null && !acc.getPassword().isEmpty()) {
                                javaPasswordSubmitted.set(true);
                                try {
                                    Thread.sleep(300);
                                    OutputStream os = process.getOutputStream();
                                    os.write((acc.getPassword() + "\n").getBytes(StandardCharsets.UTF_8));
                                    os.flush();
                                    appendLog(acc.getId(), "[AGRak] 🔑 رمز عبور فقط برای دیالوگ ورود به سرور ارسال شد.");

                                    // Schedule stats query 15s after password (when in-game)
                                    scheduleCommand(key, "/stats", 15);
                                } catch (Exception ex) {
                                    Log.e(TAG, "Error auto-submitting password", ex);
                                }
                            }
                        }

                        // Auto-trigger stats on login or sleep confirmation
                        if (lower.contains("welcome ") || lower.contains("put to sleep") || lower.contains("confirmed in sleep mode")) {
                            scheduleCommand(key, "/stats", 4);
                        } else if (lower.contains("can't execute commands when a dialog is shown") || lower.contains("dialog is shown up")) {
                            // Retry stats if server blocked it due to an open dialog
                            scheduleCommand(key, "/stats", 4);
                        }
                    }
                } catch (Exception e) {
                    appendLog(acc.getId(), "[AGRak] خطای خواندن جریان لاگ: " + e.getMessage());
                } finally {
                    try {
                        int exitCode = process.waitFor();
                        appendLog(acc.getId(), "[AGRak] پروسه راک‌سمپ با کد خروجی " + exitCode + " خاتمه یافت.");
                        if (exitCode != 0) {
                            File crashLog = new File(botDir, "RakSAMPClient.log");
                            if (crashLog.exists() && crashLog.length() > 0) {
                                try (BufferedReader cr = new BufferedReader(new FileReader(crashLog))) {
                                    String cl;
                                    List<String> lastLines = new ArrayList<>();
                                    while ((cl = cr.readLine()) != null) {
                                        lastLines.add(cl);
                                        if (lastLines.size() > 35) lastLines.remove(0);
                                    }
                                    for (String l : lastLines) {
                                        appendLog(acc.getId(), "[لاگ موتور] " + l);
                                    }
                                } catch (Exception ignored) {}
                            }
                        }
                    } catch (Exception ignored) {}
                    activeProcesses.remove(key);
                    connectedAccounts.remove(key);
                    clearAccountLogsAndChat(acc.getId());
                    clearAccountLogsAndChat(nick);
                    for (LogCallback cb : logCallbacks) {
                        try {
                            cb.onDisconnected(acc.getId());
                        } catch (Exception ignored) {}
                    }
                    updateNotification();
                }
            });
            readerThread.setDaemon(true);
            readerThread.start();
            readerThreads.put(key, readerThread);

        } catch (Exception e) {
            Log.e(TAG, "Error starting local bot", e);
            appendLog(acc.getId(), "[AGRak] ❌ خطا در راه‌اندازی ربات: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    public static synchronized void stopLocalBot(String nickname) {
        if (nickname == null) return;
        String key = nickname.toLowerCase();
        connectedAccounts.remove(key);
        Process proc = activeProcesses.remove(key);
        if (proc != null) {
            try {
                proc.destroy();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.destroyForcibly();
                }
            } catch (Exception ignored) {}
        }
        Thread t = readerThreads.remove(key);
        if (t != null && t.isAlive()) {
            t.interrupt();
        }
        String accId = nickToAccountId.get(key);
        clearAccountLogsAndChat(nickname);
        if (accId != null) {
            clearAccountLogsAndChat(accId);
            for (LogCallback cb : logCallbacks) {
                try {
                    cb.onDisconnected(accId);
                } catch (Exception ignored) {}
            }
        }
        for (LogCallback cb : logCallbacks) {
            try {
                cb.onDisconnected(nickname);
                cb.onDisconnected(key);
            } catch (Exception ignored) {}
        }
        updateNotification();
    }

    public static void sendLocalCommand(String nickname, String cmd) {
        sendLocalCommand(nickname, cmd, false);
    }

    public static void sendLocalCommand(String nickname, String cmd, boolean logToConsole) {
        if (nickname == null || cmd == null) return;
        String key = nickname.toLowerCase();
        Process proc = activeProcesses.get(key);
        if (proc != null) {
            try {
                OutputStream os = proc.getOutputStream();
                os.write((cmd + "\n").getBytes(StandardCharsets.UTF_8));
                os.flush();
                if (logToConsole) {
                    String accId = nickToAccountId.get(key);
                    if (accId != null) {
                        appendLog(accId, "> " + cmd);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error sending command", e);
            }
        }
    }

    private static void writeRakSAMPConfig(File xmlFile, String nickname) {
        String content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<RakSAMPClient console=\"1\" dialogs=\"console\" runmode=\"3\" autorun=\"0\" find=\"1\" select_classid=\"0\" manual_spawn=\"1\"\n" +
                "               print_timestamps=\"1\" log_level=\"1\" chatcolor_rgb=\"0 0 130\" clientmsg_rgb=\"0 130 0\" cpalert_rgb=\"170 0 0\"\n" +
                "               updatestats=\"1\" minfps=\"20\" maxfps=\"90\" clientversion=\"0.3.7\">\n" +
                "    <server nickname=\"" + nickname + "\" password=\"\">185.112.33.99:7777</server>\n" +
                "    <intervals spam=\"150\" fakekill=\"35\" lag=\"20\" joinflood=\"50\" chatflood=\"20\" classflood=\"30\" bulletflood=\"25\" />\n" +
                "    <log level=\"1\" objects=\"0\" pickups=\"0\" textlabels=\"0\" textdraws=\"0\" />\n" +
                "    <sendrates force=\"0\" onfoot=\"40\" incar=\"40\" firing=\"40\" multiplier=\"1\" />\n" +
                "    <scripts>autologin</scripts>\n" +
                "    <rates sleep=\"30\" connect=\"6000\" reconnect=\"3000\" network=\"0\" lua=\"50\" spectate=\"30\" />\n" +
                "    <normal_pos position=\"325.35 2512.09 16.56\" rotation=\"0.0\" force=\"0\" />\n" +
                "</RakSAMPClient>\n";

        try (FileOutputStream fos = new FileOutputStream(xmlFile)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            Log.e(TAG, "Failed to write RakSAMPClient.xml", e);
        }
    }

    private static void writeAccountConfig(File scriptsDir, AccountModel acc) {
        File configFile = new File(scriptsDir, "account_config.lua");
        String password = (acc != null && acc.getPassword() != null) ? acc.getPassword() : "";
        boolean autoLogin = (acc != null && acc.isAutoLogin());
        String escapedPass = password.replace("\\", "\\\\").replace("\"", "\\\"");

        String content = "-- Auto-generated account config for AGRak\n" +
                "PASSWORD = \"" + escapedPass + "\"\n" +
                "AUTO_LOGIN_ENABLED = " + (autoLogin && !password.isEmpty() ? "true" : "false") + "\n";

        try (FileOutputStream fos = new FileOutputStream(configFile)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            Log.e(TAG, "Failed to write account_config.lua", e);
        }
    }

    private static void prepareAutologinScript(Context context, AccountModel acc, File destFile) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (InputStream is = context.getAssets().open("scripts/autologin.lua")) {
                byte[] buf = new byte[4096];
                int r;
                while ((r = is.read(buf)) != -1) {
                    baos.write(buf, 0, r);
                }
            }
            String scriptContent = baos.toString("UTF-8");
            String password = (acc != null && acc.getPassword() != null) ? acc.getPassword() : "";
            boolean autoLogin = (acc != null && acc.isAutoLogin());

            if (autoLogin && !password.isEmpty()) {
                String escapedPass = password.replace("\\", "\\\\").replace("\"", "\\\"");
                scriptContent = scriptContent.replaceFirst("local PASSWORD = [^\r\n]+", java.util.regex.Matcher.quoteReplacement("local PASSWORD = \"" + escapedPass + "\""));
                scriptContent = scriptContent.replaceFirst("local AUTO_LOGIN_ENABLED = [^\r\n]+", "local AUTO_LOGIN_ENABLED = true");
            } else {
                scriptContent = scriptContent.replaceFirst("local PASSWORD = [^\r\n]+", "local PASSWORD = \"\"");
                scriptContent = scriptContent.replaceFirst("local AUTO_LOGIN_ENABLED = [^\r\n]+", "local AUTO_LOGIN_ENABLED = false");
            }

            try (FileOutputStream fos = new FileOutputStream(destFile)) {
                fos.write(scriptContent.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare autologin script", e);
        }
    }

    private static void copyAssetToFile(Context context, String assetPath, File destFile) {
        try (InputStream is = context.getAssets().open(assetPath);
             FileOutputStream fos = new FileOutputStream(destFile)) {
            byte[] buf = new byte[4096];
            int len;
            while ((len = is.read(buf)) > 0) {
                fos.write(buf, 0, len);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy asset " + assetPath, e);
        }
    }

    private static void copyFile(File src, File dst) {
        try (InputStream in = new java.io.FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to copy file", e);
        }
    }

    public static void ensureServiceStarted(Context context) {
        if (context == null) return;
        try {
            Intent intent = new Intent(context.getApplicationContext(), BotService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.getApplicationContext().startForegroundService(intent);
            } else {
                context.getApplicationContext().startService(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting BotService", e);
        }
    }

    public static void updateNotification() {
        BotService service = instance;
        if (service == null) return;
        int activeCount = getActiveBotsCount();
        if (activeCount == 0) {
            service.stopForegroundAndService();
        } else {
            service.refreshNotification(activeCount);
        }
    }

    public void stopForegroundAndService() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.cancel(NOTIFICATION_ID);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error stopping foreground", e);
        }
        releaseWakeLock();
        stopSelf();
    }

    public void refreshNotification(int activeCount) {
        try {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.notify(NOTIFICATION_ID, createNotification(buildNotificationText(activeCount)));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error refreshing notification", e);
        }
    }

    public static String buildNotificationText(int activeCount) {
        int onlineCount = 0;
        List<String> onlineNicks = new ArrayList<>();
        List<String> connectingNicks = new ArrayList<>();

        for (String nick : activeProcesses.keySet()) {
            if (isAccountConnected(nick)) {
                onlineCount++;
                onlineNicks.add(nick);
            } else {
                connectingNicks.add(nick);
            }
        }

        if (activeCount == 1) {
            if (onlineCount == 1 && !onlineNicks.isEmpty()) {
                return "اکانت " + onlineNicks.get(0) + " در سرور آرساکیا آنلاین است";
            } else if (!connectingNicks.isEmpty()) {
                return "اکانت " + connectingNicks.get(0) + " در حال اتصال به سرور...";
            } else {
                return "۱ اکانت فعال در سرور آرساکیا";
            }
        } else {
            if (onlineCount > 0 && onlineCount == activeCount) {
                return activeCount + " اکانت در سرور آرساکیا آنلاین است";
            } else if (onlineCount > 0) {
                return onlineCount + " از " + activeCount + " اکانت آنلاین در سرور آرساکیا";
            } else {
                return activeCount + " اکانت در حال اتصال به سرور آرساکیا...";
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createNotificationChannel();
        acquireWakeLock();

        int activeCount = getActiveBotsCount();
        if (activeCount == 0) {
            startForeground(NOTIFICATION_ID, createNotification("سرویس AGRak در حال آماده‌سازی..."));
            stopForegroundAndService();
            return;
        }

        startForeground(NOTIFICATION_ID, createNotification(buildNotificationText(activeCount)));

        // Periodically refresh stats every 90 seconds for all active bots (silent)
        scheduler.scheduleWithFixedDelay(() -> {
            try {
                for (String activeNick : activeProcesses.keySet()) {
                    sendLocalCommand(activeNick, "/stats", false);
                }
            } catch (Exception ignored) {}
        }, 30, 90, TimeUnit.SECONDS);
    }

    private synchronized void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AGRak:BotWakeLock");
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire();
            }
        } catch (Exception ignored) {}
    }

    private synchronized void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {}
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "سرویس فعال راک‌سمپ AGRak",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("اجرای مستقل ربات روی گوشی با اینترنت همراه");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public Notification createNotification(String content) {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("AGRak • آرساکیا گیم")
                .setContentText(content)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int activeCount = getActiveBotsCount();
        if (activeCount == 0) {
            stopForegroundAndService();
        } else {
            acquireWakeLock();
            refreshNotification(activeCount);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        instance = null;
        for (String nick : activeProcesses.keySet()) {
            stopLocalBot(nick);
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}