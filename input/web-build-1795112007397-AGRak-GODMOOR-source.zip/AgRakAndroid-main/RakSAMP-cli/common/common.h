#ifndef COMMON_H
#define COMMON_H

#include "SAMP_VER.h"

#define RAKSAMP_VERSION "v0.8.6-0.3.7"

#define NETCODE_CONNCOOKIELULZ 0x6969
#define NETGAME_VERSION 4057

#define AUTHOR "jlfm, bartekdvd, P3ti"

#define REJECT_REASON_BAD_VERSION	1
#define REJECT_REASON_BAD_NICKNAME	2
#define REJECT_REASON_BAD_MOD		3
#define REJECT_REASON_BAD_PLAYERID	4

#include "win_compat.h"

/* Logging verbosity (XML: log_level / <log level="...">). */
#define LOG_LEVEL_NONE  0 /* no Log / NetLog output */
#define LOG_LEVEL_INFO  1 /* normal Log() only (default) */
#define LOG_LEVEL_DEBUG 2 /* Log() + NetLog() network traces */

#ifdef __cplusplus
extern "C" {
#endif
void SetLogLevel(int level);
int GetLogLevel(void);
int ParseLogLevel(const char *value); /* "0"/"none", "1"/"info", "2"/"debug"; NULL -> INFO */
void ParseCommandLineConfig(int argc, char *argv[], const char *defaultConfig, char *configPath, size_t configPathSize);
void NetLog(const char *fmt, ...);
void FormatIPv4(unsigned int binaryAddress, char out[16]);

/* Collect basenames (no .lua) of *.lua files in directory, sorted A-Z.
   names is a flat array of nameMax-sized slots; returns count written (capped at maxNames). */
#define LUA_SCRIPT_NAME_MAX 64
int CollectLuaScriptNames(const char *directory, char names[][LUA_SCRIPT_NAME_MAX], int maxNames);
#ifdef __cplusplus
}
#endif

extern unsigned int _uiRndSrvChallenge;

#ifdef _WIN32
#define BP _asm int 3
#else
#define BP __asm__("int 3")
#endif

#define MAX_PLAYERS 1004
#define MAX_VEHICLES 2000
#define MAX_SCRIPTS 32
typedef unsigned short PLAYERID;
typedef unsigned short VEHICLEID;

#ifdef _WIN32
#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define isfinite	_finite
#endif


#define EVENT_TYPE_PAINTJOB				1
#define EVENT_TYPE_CARCOMPONENT			2
#define EVENT_TYPE_CARCOLOR				3
#define EVENT_ENTEREXIT_MODSHOP			4

#define BULLET_HIT_TYPE_NONE			0
#define BULLET_HIT_TYPE_PLAYER			1
#define BULLET_HIT_TYPE_VEHICLE			2
#define BULLET_HIT_TYPE_OBJECT			3
#define BULLET_HIT_TYPE_PLAYER_OBJECT   4

#define KEY_UP							-128
#define KEY_DOWN						128
#define KEY_LEFT						-128
#define KEY_RIGHT						128
#define KEY_ACTION						1
#define KEY_CROUCH						2
#define KEY_FIRE						4
#define KEY_SPRINT						8
#define KEY_SECONDARY_ATTACK			16
#define KEY_JUMP						32
#define KEY_LOOK_RIGHT					64
#define KEY_HANDBRAKE					128
#define KEY_LOOK_LEFT					256
#define KEY_SUBMISSION					512
#define KEY_LOOK_BEHIND					512
#define KEY_WALK						1024
#define KEY_ANALOG_UP					2048
#define KEY_ANALOG_DOWN					4096
#define KEY_ANALOG_LEFT					8192
#define KEY_ANALOG_RIGHT				16384

#pragma pack(push, 1)
typedef struct _ONFOOT_SYNC_DATA
{
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
	float fQuaternion[4];
	BYTE byteHealth;
	BYTE byteArmour;
	BYTE byteCurrentWeapon;
	BYTE byteSpecialAction;	
	float vecMoveSpeed[3];
	float vecSurfOffsets[3];
	WORD wSurfInfo;
	int	iCurrentAnimationID;
} ONFOOT_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _INCAR_SYNC_DATA
{
	VEHICLEID VehicleID;
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float fQuaternion[4];
	float vecPos[3];
	float vecMoveSpeed[3];
	float fCarHealth;
	BYTE bytePlayerHealth;
	BYTE bytePlayerArmour;
	BYTE byteCurrentWeapon;
	BYTE byteSirenOn;
	BYTE byteLandingGearState;
	WORD TrailerID_or_ThrustAngle;
	FLOAT fTrainSpeed;
} INCAR_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _PASSENGER_SYNC_DATA
{
	VEHICLEID VehicleID;
	BYTE byteSeatFlags : 7;
	BYTE byteDriveBy : 1;
	BYTE byteCurrentWeapon;
	BYTE bytePlayerHealth;
	BYTE bytePlayerArmour;
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
} PASSENGER_SYNC_DATA;
#pragma pack(pop)

enum eWeaponState
{
	WS_NO_BULLETS = 0,
	WS_LAST_BULLET = 1,
	WS_MORE_BULLETS = 2,
	WS_RELOADING = 3,
};

#pragma pack(push, 1)
typedef struct _AIM_SYNC_DATA
{
	BYTE byteCamMode;
	float vecAimf1[3];
	float vecAimPos[3];
	float fAimZ;
	BYTE byteCamExtZoom : 6;	// 0-63 normalized
	BYTE byteWeaponState : 2;	// see eWeaponState
	BYTE bUnk;
} AIM_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _UNOCCUPIED_SYNC_DATA // 67
{
	VEHICLEID VehicleID;
	short cvecRoll[3];
	short cvecDirection[3];
	BYTE unk[13];
	float vecPos[3];
	float vecMoveSpeed[3];
	float vecTurnSpeed[3];
	float fHealth;
} UNOCCUPIED_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _SPECTATOR_SYNC_DATA
{
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
} SPECTATOR_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _BULLET_SYNC_DATA {
	BYTE bHitType;
	unsigned short iHitID;
	float fHitOrigin[3];
	float fHitTarget[3];
	float fCenterOfHit[3];
	BYTE bWeaponID;
} BULLET_SYNC_DATA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _PLAYER_SPAWN_INFO
{
	BYTE byteTeam;
	int iSkin;
	BYTE unk;
	float vecPos[3];
	float fRotation;
	int iSpawnWeapons[3];
	int iSpawnWeaponsAmmo[3];
} PLAYER_SPAWN_INFO;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _PICKUP
{
	int iModel;
	int iType;
	float fX;
	float fY;
	float fZ;
} PICKUP;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _TEXT_DRAW_TRANSMIT
{
	union
	{
		BYTE byteFlags;
		struct
		{
			BYTE byteBox : 1;
			BYTE byteLeft : 1;
			BYTE byteRight : 1;
			BYTE byteCenter : 1;
			BYTE byteProportional : 1;
			BYTE bytePadding : 3;
		};
	};
	float fLetterWidth;
	float fLetterHeight;
	DWORD dwLetterColor;
	float fLineWidth;
	float fLineHeight;
	DWORD dwBoxColor;
	BYTE byteShadow;
	BYTE byteOutline;
	DWORD dwBackgroundColor;
	BYTE byteStyle;
	BYTE byteSelectable;
	float fX;
	float fY;
	WORD wModelID;
	float fRotX;
	float fRotY;
	float fRotZ;
	float fZoom;
	WORD wColor1;
	WORD wColor2;
} TEXT_DRAW_TRANSMIT;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct _NEW_VEHICLE {
    VEHICLEID VehicleId;
	int		  iVehicleType;
	float	  vecPos[3];
	float	  fRotation;
	BYTE	  aColor1;
	BYTE	  aColor2;
	float	  fHealth;
	BYTE	  byteInterior;
	DWORD	  dwDoorDamageStatus;
	DWORD	  dwPanelDamageStatus;
	BYTE	  byteLightDamageStatus;
	BYTE	  byteTireDamageStatus;
	BYTE	  byteAddSiren;
	BYTE      byteModSlots[14];
	BYTE	  bytePaintjob;
	DWORD	  cColor1;
	DWORD	  cColor2;
	BYTE	  byteUnk;
} NEW_VEHICLE;
#pragma pack(pop)

struct stPlayerInfo
{
	int iIsConnected;
	int iIsStreamedIn;
	int iGotMarkersPos;
	char szPlayerName[32];
	int iScore;
	DWORD dwPing;
	int iAreWeInAVehicle;
	BYTE byteInteriorId;
	BYTE byteIsNPC;
	int iSkin;
	DWORD dwColor;

	// STORED INFO
	ONFOOT_SYNC_DATA onfootData;
	INCAR_SYNC_DATA incarData;
	PASSENGER_SYNC_DATA passengerData;
	AIM_SYNC_DATA aimData;
	UNOCCUPIED_SYNC_DATA unocData;
	BULLET_SYNC_DATA bulletData;
};

// GTA STUFF //////////////////////////////
///////////////////////////////////////////
///////////////////////////////////////////

#define VEHICLE_LIST_ID_START			400
#define VEHICLE_LIST_SIZE				212

#define VEHICLE_CLASS_CAR				0
#define VEHICLE_CLASS_CAR_FAST			1
#define VEHICLE_CLASS_HEAVY				2
#define VEHICLE_CLASS_HELI				3
#define VEHICLE_CLASS_AIRPLANE			4
#define VEHICLE_CLASS_BIKE				5
#define VEHICLE_CLASS_BOAT				6
#define VEHICLE_CLASS_MINI				7
#define VEHICLE_CLASS_TRAILER			8
#define VEHICLE_CLASS_COUNT				9	/* # of classes */

struct vehicle_entry
{
	int			id;			// model id
	int			class_id;	// class id
	const char	*name;		// vehicle name
	int			passengers; // total passenger seats, 0-10
};

extern struct vehicle_entry vehicle_list[VEHICLE_LIST_SIZE];

#endif // COMMON_H