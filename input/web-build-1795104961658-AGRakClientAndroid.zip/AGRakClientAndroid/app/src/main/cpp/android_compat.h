#pragma once
// Minimal Windows API shims so the original AGRakClient code builds on Android/Linux.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

typedef uint8_t  BYTE;
typedef uint16_t WORD;
typedef uint32_t DWORD;
typedef BYTE*    PBYTE;
typedef int      BOOL; // Windows BOOL is a 4-byte int (matters for packed RPC structs)

static inline unsigned long long GetTickCount64() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned long long)ts.tv_sec * 1000ULL + ts.tv_nsec / 1000000ULL;
}
static inline void Sleep(unsigned int ms) { usleep(ms * 1000); }

#define sprintf_s(buf, sz, ...) snprintf((buf), (sz), __VA_ARGS__)
#define vsprintf_s(buf, sz, fmt, args) vsnprintf((buf), (sz), (fmt), (args))

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif
typedef char* PCHAR;
typedef unsigned long ULONG;
typedef unsigned int UINT;
#ifndef MAX_PATH
#define MAX_PATH 260
#endif
