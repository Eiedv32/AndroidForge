#include "main.h"

stSettings settings {};

int LoadSettings()
{
	settings.iClassID = 19;
	settings.iUpdateStats = 1;
	if (settings.server.szAddr[0] == 0) strcpy(settings.server.szAddr, "185.112.33.99");
	if (settings.server.iPort == 0) settings.server.iPort = 7777;
	return 1;
}
