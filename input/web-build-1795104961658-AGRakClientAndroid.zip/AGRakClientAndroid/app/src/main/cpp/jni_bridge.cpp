// Replaces WinMain from the Windows version: runs the same client loop in a thread
// and exposes start/stop/pollLog to Kotlin via JNI.
#include <jni.h>
#include <thread>
#include <atomic>
#include <mutex>
#include <deque>
#include <string>

#include "main.h"

stRakClient client{};

static std::atomic<bool> g_running{false};
static std::thread g_thread;
static std::mutex g_logMutex;
static std::deque<std::string> g_logLines;

void Log(const char* fmt, ...)
{
	char buffer[512];
	memset(buffer, 0, sizeof buffer);

	va_list args;
	va_start(args, fmt);
	vsnprintf(buffer, sizeof buffer, fmt, args);
	va_end(args);

	time_t now = time(nullptr);
	struct tm lt;
	localtime_r(&now, &lt);
	char line[600];
	snprintf(line, sizeof line, "[%02d:%02d:%02d] %s", lt.tm_hour, lt.tm_min, lt.tm_sec, buffer);

	std::lock_guard<std::mutex> lk(g_logMutex);
	g_logLines.emplace_back(line);
	while (g_logLines.size() > 500) g_logLines.pop_front();
}

bool isSubstring(const char* input, const char* substr)
{
	return strstr(input, substr) != nullptr;
}

static void clientLoop()
{
	client = stRakClient{};
	auto* rakClient = client.rakClient = RakNetworkFactory::GetRakClientInterface();
	if (rakClient == NULL) {
		Log("Failed to create RakClient");
		g_running = false;
		return;
	}
	rakClient->SetMTUSize(576);
	RegisterRPCs();

	while (g_running)
	{
		UpdateNetwork();

		if (client.sleepTime)
		{
			if (GetTickCount64() > client.sleepTime)
			{
				client.connectionRequested = false;
				client.sleepTime = 0;
			}
		}
		else
		{
			if (!client.connectionRequested)
			{
				sampConnect();
				client.connectionRequested = true;
			}

			if (client.areWeConnected && client.gameInited)
			{
				if (!client.spawned)
				{
					if (!client.callSampRequestClass)
					{
						sampRequestClass();
						client.callSampRequestClass = 1;
					}
				}
				else
				{
					if (!client.isSpectating) onFootUpdateAtNormalPos();
					else spectatorUpdate();

					const auto tickCount = GetTickCount64();
					if (tickCount - client.lastStatsUpdate >= 1000 || client.money != client.lastMoney || client.drunkLevel != client.lastDrunkLevel)
					{
						RakNet::BitStream bsSend;
						bsSend.Write((BYTE)ID_STATS_UPDATE);
						client.drunkLevel -= (rand() % 90 + 20);
						if (client.drunkLevel < 0) client.drunkLevel = 0;
						bsSend.Write(client.money);
						bsSend.Write(client.drunkLevel);
						client.rakClient->Send(&bsSend, HIGH_PRIORITY, RELIABLE, 0);
						client.lastMoney = client.money;
						client.lastDrunkLevel = client.drunkLevel;
						client.lastStatsUpdate = tickCount;
					}
				}
			}
		}
		Sleep(30);
	}

	sampDisconnect();
	Sleep(600);
	RakNetworkFactory::DestroyRakClientInterface(rakClient);
	client.rakClient = NULL;
	Log("Stopped.");
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_agrak_client_NativeBridge_start(JNIEnv* env, jclass, jstring user, jstring pass, jstring host, jint port)
{
	if (g_running) return JNI_FALSE;
	if (g_thread.joinable()) g_thread.join();

	const char* u = env->GetStringUTFChars(user, nullptr);
	const char* p = env->GetStringUTFChars(pass, nullptr);
	const char* h = env->GetStringUTFChars(host, nullptr);

	memset(&settings, 0, sizeof settings);
	strncpy(settings.userName, u, sizeof(settings.userName) - 1);
	strncpy(settings.userPassword, p, sizeof(settings.userPassword) - 1);
	strncpy(settings.server.szAddr, h, sizeof(settings.server.szAddr) - 1);
	settings.server.iPort = port;
	settings.bHaveUser = true;

	env->ReleaseStringUTFChars(user, u);
	env->ReleaseStringUTFChars(pass, p);
	env->ReleaseStringUTFChars(host, h);

	srand((unsigned int)GetTickCount64());
	LoadSettings();

	g_running = true;
	g_thread = std::thread(clientLoop);
	return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_agrak_client_NativeBridge_stop(JNIEnv*, jclass)
{
	g_running = false;
	if (g_thread.joinable()) g_thread.join();
}

JNIEXPORT jboolean JNICALL
Java_com_agrak_client_NativeBridge_isRunning(JNIEnv*, jclass)
{
	return g_running ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_agrak_client_NativeBridge_pollLog(JNIEnv* env, jclass)
{
	std::string out;
	{
		std::lock_guard<std::mutex> lk(g_logMutex);
		for (auto& l : g_logLines) { out += l; out += '\n'; }
		g_logLines.clear();
	}
	return env->NewStringUTF(out.c_str());
}

} // extern "C"
