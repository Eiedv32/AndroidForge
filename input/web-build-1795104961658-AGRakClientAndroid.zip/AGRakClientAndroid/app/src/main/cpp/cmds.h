void RunCommand(char* szCMD);
