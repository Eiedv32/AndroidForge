cmake_minimum_required(VERSION 3.22.1)
project(agrakclient LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

file(GLOB RAKNET_SRC ${CMAKE_CURRENT_SOURCE_DIR}/AGRaknet/*.cpp ${CMAKE_CURRENT_SOURCE_DIR}/AGRaknet/SAMP/*.cpp)

add_library(agrakclient SHARED
    ${RAKNET_SRC}
    jni_bridge.cpp xmlsets.cpp netgame.cpp netrpc.cpp misc_funcs.cpp
    localplayer.cpp math_stuff.cpp cmds.cpp common.cpp)

target_include_directories(agrakclient PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
    ${CMAKE_CURRENT_SOURCE_DIR}/AGRaknet
    ${CMAKE_CURRENT_SOURCE_DIR}/AGRaknet/SAMP)

# The original code is MSVC-era; keep it compiling on clang.
target_compile_options(agrakclient PRIVATE -w -fpermissive -include ${CMAKE_CURRENT_SOURCE_DIR}/android_compat.h)

target_link_libraries(agrakclient log)
