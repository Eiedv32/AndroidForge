package com.agrak.client

object NativeBridge {
    init { System.loadLibrary("agrakclient") }

    @JvmStatic external fun start(user: String, pass: String, host: String, port: Int): Boolean
    @JvmStatic external fun stop()
    @JvmStatic external fun isRunning(): Boolean
    @JvmStatic external fun pollLog(): String
}
