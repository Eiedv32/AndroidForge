package com.agrak.client

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var tvLog: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tvStatus: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val logBuffer = StringBuilder()

    private val poll = object : Runnable {
        override fun run() {
            val s = NativeBridge.pollLog()
            if (s.isNotEmpty()) {
                logBuffer.append(s)
                if (logBuffer.length > 20000) logBuffer.delete(0, logBuffer.length - 20000)
                tvLog.text = logBuffer
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
            tvStatus.text = if (NativeBridge.isRunning()) "Status: running" else "Status: stopped"
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("agrak", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT) =
            EditText(this).apply {
                this.hint = hint
                setText(value)
                inputType = type
                setSingleLine()
            }

        etUser = field("Username", prefs.getString("user", "") ?: "")
        etPass = field(
            "Password", prefs.getString("pass", "") ?: "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        etHost = field("Server IP", prefs.getString("host", "185.112.33.99") ?: "185.112.33.99")
        etPort = field("Port", prefs.getInt("port", 7777).toString(), InputType.TYPE_CLASS_NUMBER)

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnStart = Button(this).apply { text = "Start" }
        val btnStop = Button(this).apply { text = "Stop" }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        btnRow.addView(btnStart, lp)
        btnRow.addView(btnStop, lp)

        tvStatus = TextView(this).apply { text = "Status: stopped"; gravity = Gravity.CENTER }
        tvLog = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(tvLog) }

        root.addView(etUser)
        root.addView(etPass)
        root.addView(etHost)
        root.addView(etPort)
        root.addView(btnRow)
        root.addView(tvStatus)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        btnStart.setOnClickListener {
            val user = etUser.text.toString().trim()
            if (user.isEmpty()) { tvStatus.text = "Enter a username"; return@setOnClickListener }
            val port = etPort.text.toString().toIntOrNull() ?: 7777
            prefs.edit()
                .putString("user", user)
                .putString("pass", etPass.text.toString())
                .putString("host", etHost.text.toString().trim())
                .putInt("port", port)
                .apply()

            startForegroundService(Intent(this, ClientService::class.java).apply {
                putExtra("user", user)
                putExtra("pass", etPass.text.toString())
                putExtra("host", etHost.text.toString().trim())
                putExtra("port", port)
            })
        }

        btnStop.setOnClickListener {
            startService(Intent(this, ClientService::class.java).apply { action = ClientService.ACTION_STOP })
        }
    }

    override fun onResume() { super.onResume(); handler.post(poll) }
    override fun onPause() { handler.removeCallbacks(poll); super.onPause() }
}
