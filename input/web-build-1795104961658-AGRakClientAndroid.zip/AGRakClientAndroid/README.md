# AGRakClient for Android (v0.1 – initial port)

Port of AGRakClient (SA-MP RakNet client) to Android.
- `app/src/main/cpp`  : original C++ client + RakNet, built with the NDK (Windows API replaced by `android_compat.h`, `WinMain` replaced by `jni_bridge.cpp`)
- `app/src/main/java` : Kotlin UI + foreground service

## Build
Open this folder in Android Studio (Koala or newer), let it install NDK + CMake 3.22.1 from SDK Manager, then Run / Build > Build APK.

## Notes
- One account per app instance (the original C++ code uses global state).
- Server defaults to 185.112.33.99:7777 (editable in the UI).
