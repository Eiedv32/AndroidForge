#include <jni.h>
#include <string>
#include <cstdint>

static std::string jstr(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_godmoor_agrak_NativeEngine_engineStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF("NOT PORTED — original engine requires WinSock/WinAPI compatibility work");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_godmoor_agrak_NativeEngine_validateConfiguration(JNIEnv* env, jobject,
                                                            jstring host, jint port) {
    const auto h = jstr(env, host);
    if (h.empty() || port < 1 || port > 65535)
        return env->NewStringUTF("INVALID_CONFIGURATION");
    return env->NewStringUTF("CONFIGURATION_VALID; NETWORK_ENGINE_NOT_PORTED");
}
