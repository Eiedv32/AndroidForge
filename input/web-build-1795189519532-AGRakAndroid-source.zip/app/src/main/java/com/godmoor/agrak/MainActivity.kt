package com.godmoor.agrak

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: AccountStore
    private lateinit var list: LinearLayout
    private val bg = Color.rgb(8, 8, 8)
    private val panel = Color.rgb(22, 22, 22)
    private val white = Color.WHITE
    private val muted = Color.LTGRAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AccountStore(this)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 14f, color: Int = white) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); setPadding(dp(12), dp(8), dp(12), dp(8))
    }
    private fun field(hintText: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText; setHintTextColor(Color.GRAY); setTextColor(white); textSize = 15f
        setSingleLine(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(panel)
        if (secret) inputType = 129
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; setTextColor(white); setBackgroundColor(Color.rgb(38,38,38)); setOnClickListener { action() }
    }
    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16),dp(18),dp(16),dp(12)) }
        root.addView(label("AGRak Android", 25f))
        root.addView(label("GODMOOR  •  SA-MP CLIENT", 11f, muted))
        root.addView(label("ENGINE STATUS", 12f, muted))
        val status = runCatching { NativeEngine.engineStatus() }.getOrElse { "NATIVE ENGINE ERROR: ${it.message}" }
        root.addView(label(status, 13f, Color.rgb(255,180,80)))
        root.addView(label("ACCOUNT MANAGER", 16f))
        val username = field("Username")
        val password = field("Password", true)
        root.addView(username); root.addView(password)
        root.addView(button("ADD ACCOUNT") {
            val u = username.text.toString().trim()
            val p = password.text.toString()
            if (u.isBlank() || p.isBlank()) toast("Username and password are required")
            else try { store.save(Account(u,p)); username.text.clear(); password.text.clear(); render() }
            catch (e: Exception) { toast("Save failed: ${e.message}") }
        })
        root.addView(label("SAVED ACCOUNTS", 16f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        store.all().forEach { account ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(panel); setPadding(dp(6),dp(4),dp(6),dp(4)) }
            row.addView(label(account.username, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("DELETE") { store.remove(account.username); render() })
            list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) })
        }
        root.addView(label("Connection / multi-account execution is disabled until the original RakNet + SA-MP engine is ported.", 11f, muted))
        setContentView(root)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
