package com.godmoor.agrak

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

data class Account(val username: String, val password: String)

class AccountStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "agrak_secure_accounts",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Synchronized fun all(): List<Account> {
        val raw = prefs.getString("accounts", "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Account(o.getString("username"), o.getString("password"))
        }
    }

    @Synchronized fun save(account: Account) {
        require(account.username.isNotBlank() && account.password.isNotBlank())
        val current = all().filterNot { it.username.equals(account.username, true) }
        val next = current + account
        val array = JSONArray()
        next.forEach { array.put(JSONObject().put("username", it.username).put("password", it.password)) }
        check(prefs.edit().putString("accounts", array.toString()).commit())
    }

    @Synchronized fun remove(username: String) {
        val array = JSONArray()
        all().filterNot { it.username == username }.forEach {
            array.put(JSONObject().put("username", it.username).put("password", it.password))
        }
        check(prefs.edit().putString("accounts", array.toString()).commit())
    }
}
