package com.godmoor.agrak

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class ConnectionService : Service() {
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("agrak", "AGRak status", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "agrak").setContentTitle("AGRak Android")
                .setContentText("Connection engine is not yet ported").setSmallIcon(android.R.drawable.stat_sys_upload_done).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("AGRak Android")
                .setContentText("Connection engine is not yet ported").setSmallIcon(android.R.drawable.stat_sys_upload_done).build()
        }
        startForeground(1001, notification)
        stopSelf()
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
