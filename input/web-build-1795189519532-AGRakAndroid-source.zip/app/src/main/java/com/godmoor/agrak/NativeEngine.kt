package com.godmoor.agrak

/**
 * JNI boundary for the native SA-MP/RakNet port.
 * The current source drop is Windows/WinSock-bound; this interface deliberately
 * reports NOT_PORTED until the RakNet transport and SA-MP protocol are ported.
 */
object NativeEngine {
    init { System.loadLibrary("agrak_engine") }
    external fun engineStatus(): String
    external fun validateConfiguration(host: String, port: Int): String
}
