# AGRak Android — پایه انتقال اندروید

برند رابط: **ساخته شده توسط GodMoor**

## وضعیت صادقانه
این پروژه یک پوسته بومی Android با مدیریت امن اکانت‌ها و مرز JNI است؛ **هنوز کلاینت واقعی SA-MP نیست و اتصال شبکه انجام نمی‌دهد**.

بررسی سورس ارسالی نشان داد:
- AGRakClient یک برنامه Win32 است (`WinMain`, `windows.h`, `commctrl.h`).
- لایه RakNet از WinSock و APIهای Windows استفاده می‌کند.
- منطق پروتکل در `netgame.cpp`, `netrpc.cpp`, `localplayer.cpp`, `samp_auth` و `samp_netencr` قرار دارد.
- Runner ویندوزی با `subprocess.Popen`، `psutil` و `Runner.xml` کار می‌کند؛ این مدل اجرا در Android قابل استفاده نیست و باید به سرویس/مدیر چرخه‌عمر Kotlin منتقل شود.
- مخازن ارسالی فایل LICENSE ندارند؛ پیش از انتشار عمومی باید مجوز کد و وابستگی‌ها روشن شود.

## اجزای ساخته‌شده
- پروژه Android/Kotlin با minSdk 26
- رابط تیره AMOLED
- افزودن، نمایش و حذف اکانت
- ذخیره‌سازی رمزها با AndroidX EncryptedSharedPreferences
- سرویس foreground پایه
- CMake و JNI boundary برای موتور C++

## مانع مرحله بعد
برای اتصال واقعی باید لایه پلتفرم RakNet از WinSock/WinAPI به POSIX sockets و pthread/std::thread منتقل و تمام وابستگی‌های ویندوزی حذف یا جایگزین شوند؛ سپس حلقه `UpdateNetwork` و توابع احراز هویت/Join/Sync با تست سازگاری سرور Arsacia اجرا شوند. در این نسخه، عمداً وضعیت `NOT PORTED` نشان داده می‌شود تا برنامه اتصال جعلی گزارش نکند.

## ساخت
با Android Studio باز کنید و Gradle Sync بزنید؛ سپس Build > Build APK(s).
